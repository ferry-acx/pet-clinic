<?php 
require_once './header.php'; 


$query = "SELECT COUNT(*) as count FROM `products` where category='Pet Food' ";
$stmt = $pdo->prepare($query);
$stmt->execute();
$result = $stmt->fetch();
$pet_food = $result['count'];


$query = "SELECT COUNT(*) as count FROM `products` where category='Medicine' ";
$stmt = $pdo->prepare($query);
$stmt->execute();
$result = $stmt->fetch();
$medicine = $result['count'];


$query = "SELECT COUNT(*) as count FROM `products` where category='Vitamins' ";
$stmt = $pdo->prepare($query);
$stmt->execute();
$result = $stmt->fetch();
$vitamins = $result['count'];

$query = "SELECT COUNT(*) as count FROM `products` where category not in ('Vitamins','Medicine','Pet Food') ";
$stmt = $pdo->prepare($query);
$stmt->execute();
$result = $stmt->fetch();
$others = $result['count'];

?>

<script type="text/javascript">
	$('#nav-shop').find('a').toggleClass('active');
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
    <!--<div class="col-sm-6">
     <span class="d-flex" style="align-items: baseline;"><h1 class="">Dashboard</h1><small>Admin</small></span>
    </div> /.col 
    <div class="col-sm-6">
      <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>
  </div>--><!-- /.col -->
</div><!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
	<div class="container-fluid">

      <!-- Info boxes -->
      <div class="row">
        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box">
            <span class="info-box-icon bg-info elevation-1"><i class="fas fa-fish"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">PET FOOD</span>
              <span class="info-box-number"><?=$pet_food?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box mb-3">
            <span class="info-box-icon bg-success elevation-1"><i class="fas fa-pills"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">VITAMINS</span>
              <span class="info-box-number"><?=$vitamins?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col --> 

        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box mb-3">
            <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-syringe"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">MEDICINE</span>
              <span class="info-box-number"><?=$medicine?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
         <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box mb-3">
            <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-paw"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">OTHERS</span>
              <span class="info-box-number"><?=$others?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix hidden-md-up"></div>
       
      </div>
      <!-- /.row -->
		<div class="row mt-3">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">

			              <a  href="orders.php" data-target="" class="btn btn-sm btn-outline-success" style="border-radius: 5px;" aria-haspopup="" aria-expanded="">
					          <i class="fas fa-shopping-cart mr-2"></i>Go to Orders
					        </a>
					       

						<div class="card-tools">
							<div class="input-group input-group-sm mr-2" style="width: 300px;">
								<input type="text" name="table_search" onkeyup="searchProduct(this.value)" class="form-control float-riseght" placeholder="Search">

								<div class="input-group-append">
									<button type="submit" class="btn btn-default">
										<i class="fas fa-search"></i>
									</button>
								</div>
							</div>
						</div>
					</div>
					<!-- /.card-header -->
					<div class="card-body p-0">
						<div  id="product-container" class="" style="
						padding: 50px;
						display: grid;
						grid-template-columns: repeat(auto-fill, 200px);
						justify-content: space-between;
						gap: 50px 50px;
						">
						<?php
							$get_product = $pdo->prepare("SELECT * FROM `products` where stock!=0 ORDER BY `id` DESC");
							$get_product->execute();
							while ($product = $get_product->fetch(PDO::FETCH_OBJ)) {
                                    // var_dump($product);
						?>

							<div class="card shadow product show" id="prod-<?= $product->id ?>">

								<input type="hidden" class="id" id="prod_id-<?= $product->id ?>" value="<?= $product->id ?>">							
								<input type="hidden" class="name" id="prod_name-<?= $product->id ?>" value="<?= $product->name ?>">								
								<input type="hidden" class="code" id="prod_code-<?= $product->id ?>" value="<?= $product->code ?>">
								<input type="hidden" class="desc" id="prod_desc-<?= $product->id ?>" value="<?= $product->description ?>">
								<input type="hidden" class="price" id="prod_price-<?= $product->id ?>" value="<?= $product->price ?>">
								<input type="hidden" class="stock" id="prod_stock-<?= $product->id ?>" value="<?= $product->stock ?>">
								<input type="hidden" class="cat" id="prod_cat-<?= $product->id ?>" value="<?= $product->category ?>">

								<div class="" style="position: relative;">
									<img class="card-img-top" src="<?=$baseurl?>admin/uploads/img/products/<?= $product->img ?>" alt="Image Description">

									<div class="pt-3 pl-3" style="position: absolute; top:0; left: 0;">
										<span class="badge badge-success badge-pill" id="stock-badge-<?= $product->id ?>"><?= $product->stock?></span>
									</div>

								</div>
								<div class="card-footer text-center py-4 mt-auto">
									<a class="d-inline-block text-secondary small font-weight-medium mb-1" href="#"><?= $product->category?></a>
									<h3 class="font-size-1 font-weight-normal">

										<button class="text-secondary btn btn-outline-transparent" href="#" id="pop-<?= $product->id?>" tabindex="0" role="button" data-toggle="popover" data-trigger="click"  data-container="body" title="<?= $product->name?>" data-content="<?= $product->description?>"><h5><?= $product->name?></h5></button>
									</h3>
									<div class="d-block font-size-1 mb-2">
										<span class="font-weight-medium"><i class="fas fa-peso-sign"></i><?= number_format($product->price, 2)?></span>
									</div>
									<div class="d-flex">
										<input class="cart" id="prod_qty-<?= $product->id ?>" onkeydown="if(event.keyCode==13) document.getElementById('atc-<?=$product->id ?>').click()"  type="number" max="<?= $product->stock?>" min="1" style="width: 30%">
										<button style="width: 70%" class="btn cart btn-sm btn-outline-primary" id="atc-<?= $product->id ?>" onclick="addToCart(<?= $product->id ?>)">Add to Cart</button>
									</div>
								</div>
							</div>

						<?php
							}

						?>
							
						</div>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->
			</div>
			<!-- /.col -->
		</div>
	</div><!--/. container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<script type="text/javascript">
	
	function addToCart(id){

		var price = parseFloat($('#prod_price-'+id).val());
		var max = parseInt($('#prod_qty-'+id).attr("max"));
		var qty = parseInt($('#prod_qty-'+id).val());

		if(qty>0&&qty<=max){
			$.ajax({
				url: 'ajax.php',
				type: 'POST',
				data: {
					addToCart: 'add',
					pid: id,
					qty: qty,
					total: price*qty
				},
				beforeSend: function(){
					$("#pre-loader").css("display", "flex");
				},
				success: function(res){
					const data = JSON.parse(res);

					if(data.response == 'success'){
						$('#prod_qty-'+id).val('');
						$('#stock-badge-'+id).text(max-qty);
						$('#prod_qty-'+id).attr("max",max-qty);
						toastr.success("Added to Cart!");
					} else{
						toastr.error("Error occurred!");
					}

					$("#pre-loader").css("display", "none");
				}
			});
		} else{

				toastr.error("Invalid quantity!");
		}
	}

</script>


<script type="text/javascript">

	  $("[data-toggle=popover]").popover();

      $('[data-toggle=popover]').on('click', function (e) {
        $('[data-toggle=popover]').not(this).popover('hide');
    });

</script>

<script type="text/javascript">


	function searchProduct(keyword) {
		$('div.product').each(function(){
			$('.popover').popover('hide');
			if(keyword.trim().length>0) {
				if( $(this).find('.cat').val().toLowerCase().trim().search(keyword.toLowerCase().trim()) > -1 || $(this).find('.name').val().toLowerCase().trim().search(keyword.toLowerCase().trim()) > -1 || $(this).find('.code').val().toLowerCase().trim().search(keyword.toLowerCase().trim()) > -1 || $(this).find('.desc').val().toLowerCase().trim().search(keyword.toLowerCase().trim()) > -1 || $(this).find('.stock').val().toLowerCase().trim().search(keyword.toLowerCase().trim()) > -1 ){
					$(this).removeAttr('hidden').toggleClass('show');

					
				} else{
					$(this).attr('hidden','hidden');
				}
			} else{
				$(this).removeAttr('hidden').toggleClass('show');
			}

		})
	}
	
</script>

<?php require_once './footer.php'; ?>