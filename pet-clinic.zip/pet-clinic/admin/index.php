<?php require_once './header.php'; ?>
<script type="text/javascript">
  $('#nav-dash').find('a').toggleClass('active');
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <!--<div class="col-sm-6">
         <span class="d-flex" style="align-items: baseline;"><h1 class="">Dashboard</h1><small>Admin</small></span>
        </div> /.col 
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
          </ol>
        </div>--><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box">
            <span class="info-box-icon bg-info elevation-1"><i class="fas fa-shopping-cart"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">ORDERS</span>
              <span class="info-box-number">
                10
              </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box mb-3">
            <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-calendar-day"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">APPOINTMENTS</span>
              <span class="info-box-number">41,410</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix hidden-md-up"></div>

        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box mb-3">
            <span class="info-box-icon bg-success elevation-1"><i class="fas fa-coins"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">TOTAL REVENUE</span>
              <span class="info-box-number">760</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box mb-3">
            <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">CUSTOMERS</span>
              <span class="info-box-number">2,000</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row mt-3">
        <div class="col-md-8">
         <!-- TABLE: LATEST ORDERS -->
         <div class="card shadow">
          <div class="card-header border-transparent">
            <h3 class="card-title">RECENT ORDERS</h3>

            <div class="col text-right">
              <a href="orders.php" class="btn btn-xs btn-info elevation-1" style="border-radius: 5px;">See all</a>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table m-0">
                <thead>
                  <tr>
                    <th>ORDER ID</th>
                    <th>CUSTOMER</th>
                    <th>TOTAL</th>
                    <th>STATUS</th>
                    <th>DATE</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><a href="#">OR9842</a></td>
                    <td>Maria Clara</td>
                    <td>80</td>
                    <td><span class="badge badge-success">Shipped</span></td>
                    <td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                  <tr>
                    <td><a href="#">OR1848</a></td>
                    <td>Maria Clara</td>
                    <td>80</td>
                    <td><span class="badge badge-warning">Pending</span></td>
                    <td>
                      <div class="sparkbar" data-color="#f39c12" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                  <tr>
                    <td><a href="#">OR7429</a></td>
                    <td>Maria Clara</td>
                    <td>80</td>
                    <td><span class="badge badge-danger">Delivered</span></td>
                    <td>
                      <div class="sparkbar" data-color="#f56954" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                  <tr>
                    <td><a href="#">OR7429</a></td>
                    <td>Maria Clara</td>
                    <td>80</td>
                    <td><span class="badge badge-info">Processing</span></td>
                    <td>
                      <div class="sparkbar" data-color="#00c0ef" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                  <tr>
                    <td><a href="#">OR1848</a></td>
                    <td>Maria Clara</td>
                    <td>80</td>
                    <td><span class="badge badge-warning">Pending</span></td>
                    <td>
                      <div class="sparkbar" data-color="#f39c12" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                  <tr>
                    <td><a href="#">OR7429</a></td>
                    <td>Maria Clara</td>
                    <td>80</td>
                    <td><span class="badge badge-danger">Delivered</span></td>
                    <td>
                      <div class="sparkbar" data-color="#f56954" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- /.table-responsive -->
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
      <div class="col-md-4">
        <!-- Info Boxes Style 2 -->
        <a href="orders.php#sales">
        <div class="info-box mb-3 bg-lightblue">
          <span class="info-box-icon"><i class="fas fa-peso-sign"></i></span>

          <div class="info-box-content">
            <span class="info-box-text">SALES</span>
            <span class="info-box-number">163,921</span>
          </div>
          <!-- /.info-box-content -->
        </div></a>
        <!-- /.info-box -->
        <div class="info-box mb-3 bg-success">
          <span class="info-box-icon"><i class="fas fa-check-to-slot"></i></span>

          <div class="info-box-content">
            <span class="info-box-text">COMPLETED</span>
            <span class="info-box-number">92,050</span>
          </div>
          <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
        <div class="info-box mb-3 bg-warning">
          <span class="info-box-icon"><i class="fas fa-hourglass-half"></i></span>

          <div class="info-box-content">
            <span class="info-box-text">PENDING</span>
            <span class="info-box-number">5,200</span>
          </div>
          <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
        <div class="info-box mb-3 bg-danger">
          <span class="info-box-icon"><i class="fas fa-ban"></i></span>

          <div class="info-box-content">
            <span class="info-box-text">CANCELLED</span>
            <span class="info-box-number">114,381</span>
          </div>
          <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
      </div>
    </div>
    <!-- /.row -->
    <div class="row mt-3">
      <div class="col-md-8">
        <!-- TABLE: LATEST ORDERS -->
        <div class="card shadow">
          <div class="card-header border-transparent">
            <h3 class="card-title">RECENT APPOINTMENTS</h3>

            <div class="col text-right">
              <a href="appointments.php" class="btn btn-xs btn-info elevation-1" style="border-radius: 5px;">See all</a>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table m-0">
                <thead>
                  <tr>
                    <th>APPT. ID</th>
                    <th>CUSTOMER</th>
                    <th>PURPOSE</th>
                    <th>STATUS</th>
                    <th>DATE</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><a href="#">OR9842</a></td>
                    <td>Juan de la Cruz</td>
                    <td>Check-upV</td>
                    <td><span class="badge badge-warning">For Approval</span></td>
                    <td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                  <tr>
                    <td><a href="#">OR9842</a></td>
                    <td>Juan de la Cruz</td>
                    <td>Check-upV</td>
                    <td><span class="badge badge-success">Attended</span></td>
                    <td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                  <tr>
                    <td><a href="#">OR9842</a></td>
                    <td>Juan de la Cruz</td>
                    <td>Check-upV</td>
                    <td><span class="badge badge-danger">Cancelled</span></td>
                    <td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                  <tr>
                    <td><a href="#">OR9842</a></td>
                    <td>Juan de la Cruz</td>
                    <td>Check-upV</td>
                    <td><span class="badge badge-success">Attended</span></td>
                    <td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                  <tr>
                    <td><a href="#">OR9842</a></td>
                    <td>Juan de la Cruz</td>
                    <td>Check-upV</td>
                    <td><span class="badge badge-success">Attended</span></td>
                    <td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20">2022-12-25</div>
                    </td>
                  </tr>

                  <tr>
                    <td><a href="#">OR9842</a></td>
                    <td>Juan de la Cruz</td>
                    <td>Check-upV</td>
                    <td><span class="badge badge-warning">For Approval</span></td>
                    <td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20">2022-12-25</div>
                    </td>
                  </tr>

                  <tr>
                    <td><a href="#">OR9842</a></td>
                    <td>Juan de la Cruz</td>
                    <td>Check-upV</td>
                    <td><span class="badge badge-success">Shipped</span></td>
                    <td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                  <tr>
                    <td><a href="#">OR9842</a></td>
                    <td>Juan de la Cruz</td>
                    <td>Check-upV</td>
                    <td><span class="badge badge-danger">Cancelled</span></td>
                    <td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20">2022-12-25</div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- /.table-responsive -->
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <div class="col-md-4">
        
            <!-- TO DO List -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="ion ion-clipboard mr-1"></i>
                  TODAY'S SCHEDULE
                </h3>

                <div class="card-tools">
                  <ul class="pagination pagination-sm">
                    <li class="page-item"><a href="#" class="page-link">&laquo;</a></li>
                    <li class="page-item"><a href="#" class="page-link">1</a></li>
                    <li class="page-item"><a href="#" class="page-link">2</a></li>
                    <li class="page-item"><a href="#" class="page-link">3</a></li>
                    <li class="page-item"><a href="#" class="page-link">&raquo;</a></li>
                  </ul>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <ul class="todo-list" data-widget="todo-list">
                  <li>
                    <!-- todo text -->
                    <span class="text">Surgery</span>
                    <!-- Emphasis label -->
                    <small class="badge badge-danger float-right" ><i class="far fa-clock"></i> 2 mins</small>
                    <!-- General tools such as edit or delete-->
                    <div class="tools float-right">
                      <i class="fas fa-edit"></i>
                      <i class="fas fa-times"></i>
                    </div>
                  </li>
                  <li>
                    <!-- todo text -->
                    <span class="text">Consultation</span>
                    <!-- Emphasis label -->
                    <small class="badge badge-danger float-right" ><i class="far fa-clock"></i> 2 mins</small>
                    <!-- General tools such as edit or delete-->
                    <div class="tools float-right">
                      <i class="fas fa-edit"></i>
                      <i class="fas fa-times"></i>
                    </div>
                  </li>
                  <li>
                    <!-- todo text -->
                    <span class="text">Surgery</span>
                    <!-- Emphasis label -->
                    <small class="badge badge-danger float-right" ><i class="far fa-clock"></i> 2 mins</small>
                    <!-- General tools such as edit or delete-->
                    <div class="tools float-right">
                      <i class="fas fa-edit"></i>
                      <i class="fas fa-times"></i>
                    </div>
                  </li>
                  <li>
                    <!-- todo text -->
                    <span class="text">Consultation</span>
                    <!-- Emphasis label -->
                    <small class="badge badge-danger float-right" ><i class="far fa-clock"></i> 2 mins</small>
                    <!-- General tools such as edit or delete-->
                    <div class="tools float-right">
                      <i class="fas fa-edit"></i>
                      <i class="fas fa-times"></i>
                    </div>
                  </li>
                  <li>
                    <!-- todo text -->
                    <span class="text">Consultation</span>
                    <!-- Emphasis label -->
                    <small class="badge badge-danger float-right" ><i class="far fa-clock"></i> 2 mins</small>
                    <!-- General tools such as edit or delete-->
                    <div class="tools float-right">
                      <i class="fas fa-edit"></i>
                      <i class="fas fa-times"></i>
                    </div>
                  </li>
                  <li>
                    <!-- todo text -->
                    <span class="text">Consultation</span>
                    <!-- Emphasis label -->
                    <small class="badge badge-danger float-right" ><i class="far fa-clock"></i> 2 mins</small>
                    <!-- General tools such as edit or delete-->
                    <div class="tools float-right">
                      <i class="fas fa-edit"></i>
                      <i class="fas fa-times"></i>
                    </div>
                  </li>
                  <li>
                    <!-- todo text -->
                    <span class="text">Surgery</span>
                    <!-- Emphasis label -->
                    <small class="badge badge-danger float-right" ><i class="far fa-clock"></i> 2 mins</small>
                    <!-- General tools such as edit or delete-->
                    <div class="tools float-right">
                      <i class="fas fa-edit"></i>
                      <i class="fas fa-times"></i>
                    </div>
                  </li>
                  <li>
                    <!-- todo text -->
                    <span class="text">Consultation</span>
                    <!-- Emphasis label -->
                    <small class="badge badge-danger float-right" ><i class="far fa-clock"></i> 2 mins</small>
                    <!-- General tools such as edit or delete-->
                    <div class="tools float-right">
                      <i class="fas fa-edit"></i>
                      <i class="fas fa-times"></i>
                    </div>
                  </li>
                </ul>
              </div>
              <!-- /.card-body -->
              <div class="card-footer clearfix d-flex" style="justify-content: center;">
                <a href="appointments.php#schedules" type="button" class="btn btn-block btn-xs btn-primary"><i class="fas fa-edit"></i> Manage Schedules</a>
              </div>
            </div>
            <!-- /.card -->
      </div>
    </div>
  </div><!--/. container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php require_once './footer.php'; ?>