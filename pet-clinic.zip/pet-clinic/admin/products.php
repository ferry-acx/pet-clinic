<?php require_once './header.php'; ?>
<script type="text/javascript">
	$('#nav-prod').find('a').toggleClass('active');
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
    <!--<div class="col-sm-6">
     <span class="d-flex" style="align-items: baseline;"><h1 class="">Dashboard</h1><small>Admin</small></span>
    </div> /.col 
    <div class="col-sm-6">
      <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>
  </div>--><!-- /.col -->
</div><!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
	<div class="container-fluid">

      <!-- Info boxes -->
      <div class="row">
        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box">
            <span class="info-box-icon bg-info elevation-1"><i class="fas fa-fish"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">PET FOOD</span>
              <span class="info-box-number">
                10
              </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box mb-3">
            <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-pills"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">VITAMINS AND SUPPLIMENTS</span>
              <span class="info-box-number">41,410</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix hidden-md-up"></div>

        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box mb-3">
            <span class="info-box-icon bg-success elevation-1"><i class="fas fa-syringe"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">MEDICINE</span>
              <span class="info-box-number">760</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-12 col-sm-6 col-md-3">
          <div class="info-box mb-3">
            <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-house-medical-circle-exclamation"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">ITEM ISSUES</span>
              <span class="info-box-number">2,000</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
		<div class="row mt-3">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<a href="#" class="btn btn-sm btn-outline-success" style="border-radius: 5px;">
			                <i class="fas fa-plus"></i>
			                &nbsp;Add New Product
			              </a>

						<div class="card-tools">
							<div class="input-group input-group-sm mr-2" style="width: 300px;">
								<input type="text" name="table_search" class="form-control float-riseght" placeholder="Search">

								<div class="input-group-append">
									<button type="submit" class="btn btn-default">
										<i class="fas fa-search"></i>
									</button>
								</div>
							</div>
						</div>
					</div>
					<!-- /.card-header -->
					<div class="card-body p-0">
						<div class="" style="
						padding: 50px;
						display: grid;
						grid-template-columns: repeat(auto-fill, 200px);
						justify-content: space-between;
						gap: 50px 50px;
						">
							<div class="card d-block shadow">
								<div class="" style="position: relative;">
									<img class="card-img-top" src="../assets/img/pet-food.jpg" alt="Image Description">

									<div class="pt-3 pl-3" style="position: absolute; top:0; left: 0;">
										<span class="badge badge-success badge-pill">45</span>
									</div>

								</div>
								<div class="card-footer text-center py-4">
									<a class="d-inline-block text-secondary small font-weight-medium mb-1" href="#">Pet Food</a>
									<h3 class="font-size-1 font-weight-normal">
										<a class="text-secondary" href="#">Dog Food</a>
									</h3>
									<div class="d-block font-size-1 mb-2">
										<span class="font-weight-medium">$56.99</span>
									</div>
									<a class="btn btn-sm btn-outline-primary btn-pill transition-3d-hover px-5" style="border-radius: 50px" href="#">View</a>
								</div>
							</div>
							<div class="card d-block shadow">
								<div class="" style="position: relative;">
									<img class="card-img-top" src="../assets/img/pet-food.jpg" alt="Image Description">

									<div class="pt-3 pl-3" style="position: absolute; top:0; left: 0;">
										<span class="badge badge-success badge-pill">45</span>
									</div>

								</div>
								<div class="card-footer text-center py-4">
									<a class="d-inline-block text-secondary small font-weight-medium mb-1" href="#">Pet Food</a>
									<h3 class="font-size-1 font-weight-normal">
										<a class="text-secondary" href="#">Dog Food</a>
									</h3>
									<div class="d-block font-size-1 mb-2">
										<span class="font-weight-medium">$56.99</span>
									</div>
									<a class="btn btn-sm btn-outline-primary btn-pill transition-3d-hover px-5" style="border-radius: 50px" href="#">View</a>
								</div>
							</div>
							<div class="card d-block shadow">
								<div class="" style="position: relative;">
									<img class="card-img-top" src="../assets/img/pet-food.jpg" alt="Image Description">

									<div class="pt-3 pl-3" style="position: absolute; top:0; left: 0;">
										<span class="badge badge-success badge-pill">45</span>
									</div>

								</div>
								<div class="card-footer text-center py-4">
									<a class="d-inline-block text-secondary small font-weight-medium mb-1" href="#">Pet Food</a>
									<h3 class="font-size-1 font-weight-normal">
										<a class="text-secondary" href="#">Dog Food</a>
									</h3>
									<div class="d-block font-size-1 mb-2">
										<span class="font-weight-medium">$56.99</span>
									</div>
									<a class="btn btn-sm btn-outline-primary btn-pill transition-3d-hover px-5" style="border-radius: 50px" href="#">View</a>
								</div>
							</div>
							<div class="card d-block shadow">
								<div class="" style="position: relative;">
									<img class="card-img-top" src="../assets/img/pet-food.jpg" alt="Image Description">

									<div class="pt-3 pl-3" style="position: absolute; top:0; left: 0;">
										<span class="badge badge-success badge-pill">45</span>
									</div>

								</div>
								<div class="card-footer text-center py-4">
									<a class="d-inline-block text-secondary small font-weight-medium mb-1" href="#">Pet Food</a>
									<h3 class="font-size-1 font-weight-normal">
										<a class="text-secondary" href="#">Dog Food</a>
									</h3>
									<div class="d-block font-size-1 mb-2">
										<span class="font-weight-medium">$56.99</span>
									</div>
									<a class="btn btn-sm btn-outline-primary btn-pill transition-3d-hover px-5" style="border-radius: 50px" href="#">View</a>
								</div>
							</div>
							<div class="card d-block shadow">
								<div class="" style="position: relative;">
									<img class="card-img-top" src="../assets/img/pet-food.jpg" alt="Image Description">

									<div class="pt-3 pl-3" style="position: absolute; top:0; left: 0;">
										<span class="badge badge-success badge-pill">45</span>
									</div>

								</div>
								<div class="card-footer text-center py-4">
									<a class="d-inline-block text-secondary small font-weight-medium mb-1" href="#">Pet Food</a>
									<h3 class="font-size-1 font-weight-normal">
										<a class="text-secondary" href="#">Dog Food</a>
									</h3>
									<div class="d-block font-size-1 mb-2">
										<span class="font-weight-medium">$56.99</span>
									</div>
									<a class="btn btn-sm btn-outline-primary btn-pill transition-3d-hover px-5" style="border-radius: 50px" href="#">View</a>
								</div>
							</div>
							<div class="card d-block shadow">
								<div class="" style="position: relative;">
									<img class="card-img-top" src="../assets/img/pet-food.jpg" alt="Image Description">

									<div class="pt-3 pl-3" style="position: absolute; top:0; left: 0;">
										<span class="badge badge-success badge-pill">45</span>
									</div>

								</div>
								<div class="card-footer text-center py-4">
									<a class="d-inline-block text-secondary small font-weight-medium mb-1" href="#">Pet Food</a>
									<h3 class="font-size-1 font-weight-normal">
										<a class="text-secondary" href="#">Dog Food</a>
									</h3>
									<div class="d-block font-size-1 mb-2">
										<span class="font-weight-medium">$56.99</span>
									</div>
									<a class="btn btn-sm btn-outline-primary btn-pill transition-3d-hover px-5" style="border-radius: 50px" href="#">View</a>
								</div>
							</div>
							
						</div>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->
			</div>
			<!-- /.col -->
		</div>
	</div><!--/. container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php require_once './footer.php'; ?>