<?php require_once './header.php'; ?>
<script type="text/javascript">
  $('#nav-appt').find('a').toggleClass('active');
</script>


<?php require_once './footer.php'; ?>