 <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-light">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.2.0
    </div>
  </footer>
</div>
<!-- ./wrapper -->

<!-- jQuery UI -->
<script src="<?= $baseurl?>assets/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Bootstrap -->
<script src="<?= $baseurl?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= $baseurl?>assets/js/adminlte.min.js"></script>
<!-- fullCalendar 2.2.5 --> 
<script src="<?= $baseurl?>assets/plugins/moment/moment.min.js"></script>
<script src="<?= $baseurl?>assets/plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?= $baseurl?>assets/plugins/fullcalendar/main.js"></script>


</body>
</html>
